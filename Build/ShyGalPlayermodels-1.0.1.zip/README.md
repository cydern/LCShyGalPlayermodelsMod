# ShyGal Playermodels v1.0.0
### The Definitive ShyGal Mod for Lethal Company!
This mod adds a variety of ShyGal models to your ship's suit rack with the intention of being as optimized and seamless as possible. I started the project after trying on different ShyGal mods that didn't feel functional, or especially "proportionally appropriate", so after tackling the issue from scratch, I felt so happy with how the mod turned out to make it public! It's certainly not perfect, but hopefully it'll soar for future updates.

### Features
  - 9 Different Variants, each with a different color and personality
  - Facial expressions while emoting or after death
  - Supports expressions for emotes from the TooManyEmotes mod! (Only a very select few, more in future updates)

### Original Model By CryptiaCurves, check it out!: https://cryptiacurves.itch.io/customizable-shygal-3d-models
  Disclaimer, while the original model was designed to be 18+, I have gladly put in the work to edit the meshes and textures to keep everything SFW :)

## Changelog
      - v1.0.1
         - Fixed none of the suits showing up on the rack when downloading from Thunderstore Mod Manager due to its insistence on being in a specifically named folder
      - v1.0.0
		- Release
### Known issues
   - Having the TooManyEmotes installed can result in vanilla emotes not affecting face expressions
   - Model's arms aren't accurate which can cause some weird poses on certain emotes
   - Ragdoll on death is incredibly wooden and can get stuck easily, causing some weird visual heckery